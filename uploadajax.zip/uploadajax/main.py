#uploadajax/main.py
from typing import Union
 
from fastapi import FastAPI, Request, UploadFile, File
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

import os

IMAGEDIR = "images/"
#python program to check if a directory exists
# Check whether the specified path exists or not
if not os.path.exists(IMAGEDIR):
   # Create a new directory because it does not exist
   os.makedirs(IMAGEDIR)
   print("The new directory is created!")


app = FastAPI()
templates = Jinja2Templates(directory="templates")
 
@app.get('/', response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
 
@app.post('/uploadfile', response_class=HTMLResponse)
async def post_basic_form(request: Request, file: UploadFile = File(...)):
    print(f'Filename: {file.filename}')
      
    contents = await file.read()
      
    #save the file
    with open(f"{IMAGEDIR}{file.filename}", "wb") as f:
        f.write(contents)
    
    return templates.TemplateResponse('success.html', context={'request': request})